# SelectiveHistoryExtension
Chrome extension that prevents history in requested domains
